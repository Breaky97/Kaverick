<?xml version="1.0" encoding="UTF-8"?>
<tileset name="NES - Super Mario Bros - Tileset" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="696" columns="29">
 <image source="NES - Super Mario Bros - Tileset.png" width="528" height="448"/>
</tileset>
