<?xml version="1.0" encoding="UTF-8"?>
<tileset name="background" tilewidth="16" tileheight="16" tilecount="300" columns="20">
 <image source="background.png" width="320" height="240"/>
</tileset>
