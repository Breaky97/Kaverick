package com.mygdx.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.Scenes.Hud;
import com.mygdx.game.SuperGroot;

public class Brick extends InteractiveTileObject {
    public Brick(World world, TiledMap map, Rectangle bounds){
        super(world, map, bounds);
        fixture.setUserData(this);
        setCategoryFilter(SuperGroot.BRICK_BIT);
    }

    @Override
    public void onFeetHit() {
        Gdx.app.log("Brick", "Collision");
        setCategoryFilter(SuperGroot.DESTROYED_BIT);
        //getCell().setTile(null);
        Hud.addScore(50);

    }
}
