package com.mygdx.game.Sprites;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.EdgeShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import com.mygdx.game.Screens.PlayScreen;
import com.mygdx.game.SuperGroot;

public class Groot extends Sprite {
    public World world;
    public Body b2body;
    private TextureRegion grootStands;
    public enum State{FALLING, JUMPING, STANDING, RUNNING, OVER};
    public State currentState;
    public State previousState;
    //private Animation<TextureRegion> timeOver;//dodo
    private Animation<TextureRegion> grootRun;
    private Animation<TextureRegion> grootJump;
    private float stateTImer;
    private boolean runningRight;
    //private boolean timeIsOver;//dodano



    public Groot(World world, PlayScreen screen){
        super(screen.getAtlas().findRegion("little_mario"));

        this.world = world;
        currentState = State.STANDING;
        previousState = State.STANDING;
        stateTImer = 0;
        runningRight = true;

        Array<TextureRegion> frames = new Array<TextureRegion>();
        for(int i = 1; i < 4; i++)
            frames.add(new TextureRegion(getTexture(),i * 16, 11, 16, 16));
        grootRun = new Animation(0.1f, frames);
        frames.clear();
        for(int i = 4; i < 6; i++)
            frames.add(new TextureRegion(getTexture(),i * 16, 11, 16, 16));
        grootJump = new Animation(0.1f, frames);

        defineGroot();
        grootStands = new TextureRegion(getTexture(),0 ,11 ,16 ,16);
        setBounds(0, 0, 16 / SuperGroot.PPM, 16 / SuperGroot.PPM);
        setRegion(grootStands);

    }

    public void update(float dt){
        setPosition(b2body.getPosition().x - getWidth() / 2, b2body.getPosition().y - getHeight() / 2);
        setRegion(getFrame(dt));
    }

    public TextureRegion getFrame(float dt){
        currentState = getState();

        TextureRegion region;
        switch (currentState){
           // case OVER://dodano
              //  region = timeOver;//dodano
                //break;//dodano
            case JUMPING:
                region = grootJump.getKeyFrame(stateTImer);
                break;
            case RUNNING:
                region = grootRun.getKeyFrame(stateTImer, true);
                break;
            case FALLING:
            case STANDING:
            default:
                region = grootStands;
                break;
        }
        if((b2body.getLinearVelocity().x < 0 || !runningRight) && !region.isFlipX()){

            region.flip(true, false);
            runningRight = false;
        }
        else if ((b2body.getLinearVelocity().x > 0 || runningRight) && region.isFlipX()){
            region.flip(true, false);
            runningRight = true;
        }
        stateTImer = currentState == previousState ? stateTImer + dt : 0;
        previousState = currentState;
        return region;
    }

    public State getState(){
       // if(timeIsOver)//dodano
         //   return State.OVER;//dodano
        if((b2body.getLinearVelocity().y > 0 && currentState == State.JUMPING) || (b2body.getLinearVelocity().y < 0 && previousState == State.JUMPING))
            return State.JUMPING;
        if(b2body.getLinearVelocity().y < 0)
            return State.FALLING;
        else if(b2body.getLinearVelocity().x !=0)
            return  State.RUNNING;
        else
            return State.STANDING;
    }

    public void defineGroot(){
        BodyDef bdef = new BodyDef();
        bdef.position.set(180 / SuperGroot.PPM, 190 / SuperGroot.PPM);
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody(bdef);

        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();
        shape.setRadius(6 / SuperGroot.PPM);
        fdef.filter.categoryBits = SuperGroot.GROOT_BIT;
        fdef.filter.maskBits = SuperGroot.DEFAULT_BIT | SuperGroot.COIN_BIT | SuperGroot.BRICK_BIT;


        fdef.shape = shape;
        b2body.createFixture(fdef);

        EdgeShape feet = new EdgeShape();
        feet.set(new Vector2(-2 / SuperGroot.PPM, -8 / SuperGroot.PPM), new Vector2(2 / SuperGroot.PPM, -8 / SuperGroot.PPM));
        fdef.shape = feet;
        fdef.isSensor = true;

        b2body.createFixture(fdef).setUserData("feet");
    }


}
