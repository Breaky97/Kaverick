<?xml version="1.0" encoding="UTF-8"?>
<tileset name="redlevel" tilewidth="16" tileheight="16" tilecount="4" columns="4">
 <image source="redlevel.png" width="72" height="16"/>
</tileset>
