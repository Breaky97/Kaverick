<?xml version="1.0" encoding="UTF-8"?>
<tileset name="level1" tilewidth="16" tileheight="16" tilecount="2" columns="2">
 <image source="level1.png" width="32" height="16"/>
</tileset>
